/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week6;

import java.util.Scanner;

/**
 *
 * @author Miit
 */
public class Q3 {
    //declare the main method
    public static void main(String [] args)
    {
        //scanner class - for input
        Scanner sc = new Scanner(System.in);
        
        //declare variable to use
        int student_serial_number;
        int student_exam_score;
        char grade;
                
        //prompt for student_serial_number
        System.out.println("Please enter your student serial number ;");
        
        //get student_serial_number
        student_serial_number=sc.nextInt();
        
        //prompt for student_exam_score
        System.out.println("Please enter your exam score :");
        
        //get student_exam_score
        student_exam_score=sc.nextInt();
        
        //
        if (student_exam_score >= 90)
            grade = 'A';
        else if (student_exam_score >= 80)
            grade = 'B';
        else if (student_exam_score >= 70)
            grade = 'C';
        else if (student_exam_score >= 60)
            grade = 'D';
        else
            grade = 'F';
        
        //display grade
        System.out.println("The grade for this student :"+grade);
        
                }//endmain
}//endclass

