/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week6;

import java.util.*;

/**
 *
 * @author Miit
 */
public class Q1 {
    //declare the main method
    
    public static void main(String [] args)
    {
        //scanner class - for input
        Scanner scanner = new Scanner(System.in);
        
        //declare integers
        int integer_1, integer_2;
        double quotinent;
        
        //prompt integer_1
        System.out.println("Please enter integer 1 ;");
        
        //get integer_1
        integer_1 = scanner.nextInt();
        
        //prompt integer_2
        System.out.println("Please enter integer 2 ;");
        
        //get integer_2
        integer_2 = scanner.nextInt();
        
        //calculate sum
        int sum = integer_1 + integer_2;
        
        //calculate difference
        int difference = integer_1 - integer_2;
        
        //calculate product
        int product = integer_1 + integer_2;
        
        //calculate quotinent
        if (integer_2 != 0){
            quotinent = integer_1 / integer_2;
        }
        else
        {
            quotinent = 0;
        }
        //display sum
        System.out.println("The sum is :"+sum);
        
        //display difference
        System.out.println("The difference is :"+difference);
        
        //display product
        System.out.println("The product is :"+product);
        
        //display quotinent
        if (quotinent != 0)
        {
            System.out.println("The quotinent is :"+quotinent);
        }    
        else
        {    
            System.out.println("The quotinent is incalculable");
        }
            
    }//end main
}//endclass
    
