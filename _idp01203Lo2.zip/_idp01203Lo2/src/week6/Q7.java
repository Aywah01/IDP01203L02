/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week6;

import java.util.Scanner;

/**
 *
 * @author Miit
 */
public class Q7 {
    //declare the main method
    public static void main(String [] args)
    {
        //scanner class - for input
        Scanner scanner = new Scanner(System.in);
        
        //declare variable to use
        int actual_loan;
        double required_deposit = 0;
                
        //prompt for actual_loan
        System.out.println("Please enter the actual loan ;");
        
        //get actual_loan
        actual_loan = scanner.nextInt();
        
        //if actual_loan is invalid
        if (actual_loan > 100000)
            //display grade
            System.out.println("the actual loan is invalid");
        else
            if (actual_loan < 25000)
            {
		required_deposit = 0.05 * actual_loan;
                        }
            else 
                if ((actual_loan >= 25000) && (actual_loan < 50000))
        {
		required_deposit = 1250 + (0.1 * actual_loan);
        }
            else 
                if ((actual_loan >= 50000) && (actual_loan <100000))
        {
                    required_deposit = 5000 + (0.25 * actual_loan);
        }
          
        //display required_deposit
        System.out.println("The amount of deposit required is :"+required_deposit);
        
                }//endmain
}//endclass
    
