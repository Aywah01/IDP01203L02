/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week5.tutorial1;

import java.util.*;

/**
 *
 * @author Miit
 */
public class temperature {
    
public static void main(String [] args)
{
    
    //scanner class – for input
    Scanner scanner = new Scanner(System.in);

    //declare variable to be use 
    int celcius; 
    int fahrenheit;
    //prompt for fahrenheit
    System.out.println("Please enter fahrenheit:");

    //get fahrenheit
    fahrenheit=scanner.nextInt();

    //calculate the celcius
    celcius = (int) ((5.0/9.0)*(fahrenheit - 32.0));

    //display the celcius
    System.out.println("The temperature in celcius is: " +celcius);

    }//end of main
}//end of class     

